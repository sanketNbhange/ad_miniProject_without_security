package com.grievance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.grievance.dbutil.DbUtil;
import com.grievance.dto.ComplaintDto;
import com.grievance.model.Complaint;
import com.grievance.model.Department;

public class DepartDaoimpl implements DepartmentDao {

	public List<Complaint> getAllComplaint() throws Exception {
		String sql = "SELECT * FROM complaint";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ResultSet rs = ps.executeQuery();

		List<Complaint> complaints = new ArrayList<Complaint>();
		while (rs.next()) {
			complaints.add(new Complaint(rs.getString(1), rs.getString(2), rs.getBytes(3), rs.getInt(4),
					rs.getDate(5).toLocalDate(), rs.getDate(6).toLocalDate(), rs.getString(7), rs.getString(8), 
					rs.getString(9),  rs.getString(10), rs.getString(11), rs.getString(12),rs.getDate(13).toLocalDate()));
		}
		return complaints;
	}
	
	
	@Override
	public int updateDeptRemark(String complaintId, String message) throws Exception {
		String sql = "UPDATE complaint SET headremark = ? where complaintid = ? " ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, message);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}
	
	@Override
	public int updateStatus(String complaintId, String status) throws Exception {
		String sql = "UPDATE complaint SET complaintstatus = ? where complaintid = ? " ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, status);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}
	
	
	@Override
	public int transferComplaint(String complaintId, String deptId) throws Exception {
		String sql = "UPDATE complaint SET deptid = ? WHERE  complaintid = ? " ;
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, deptId);
		ps.setString(2, complaintId);
		return ps.executeUpdate();
	}
	

	@Override
	public List<Complaint> getAllComplaintById(String deptid) throws Exception {
		String sql = "SELECT * FROM complaint where deptid = ?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, deptid);
		ResultSet rs = ps.executeQuery();

		List<Complaint> complaints = new ArrayList<Complaint>();
		while (rs.next()) {
			complaints.add(new Complaint(rs.getString(1), rs.getString(2), rs.getBytes(3), rs.getInt(4),
					rs.getDate(5).toLocalDate(), rs.getDate(6).toLocalDate(), rs.getString(7), rs.getString(8), 
					rs.getString(9),  rs.getString(10), rs.getString(11), rs.getString(12),rs.getDate(13).toLocalDate()));
		}
		return complaints;
	}
	@Override
	public List<ComplaintDto>  getAllComplaintByDeptId(String deptid) throws Exception {
		String sql = "select complaint.complaintid ,user.name, user.email,complaint.complaintmsg, complaint.userremark, complaint.headremark, complaint.screenshot,complaint.complaintdate,complaint.updatecount, complaint.complaintstatus from complaint inner join user on complaint.userid = user.userid where complaint.deptid =?";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);
		ps.setString(1, deptid);
		ResultSet rs = ps.executeQuery();

		List<ComplaintDto> complaintInfo = new ArrayList<ComplaintDto>();
		while (rs.next()) {
			
			complaintInfo.add(new ComplaintDto(rs.getString(1), rs.getString(2),rs.getString(3), rs.getString(4),
					rs.getString(5),rs.getString(6), rs.getBytes(7),rs.getDate(8).toLocalDate(),rs.getInt(9), rs.getString(10)));
		}
		return complaintInfo;
	}
}
