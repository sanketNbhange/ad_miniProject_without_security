package com.grievance.dao;

import java.util.List;

import com.grievance.dto.ComplaintDto;
import com.grievance.model.Address;
import com.grievance.model.Complaint;
import com.grievance.model.User;

public interface CitizenDaoI {

	public String addCitizen(User user) throws Exception; //register user (add registered user in DB)
	public List<Complaint> getAllCitizenComplaint(String userId) throws Exception;
	//public User getCitizen(String email, String password) throws Exception; //get the user based on email and password (login)
	public int updateCitizenRemark(String complaintId,String message) throws Exception;
	public int getCount(String complaintId) throws Exception;
	public int updateReminder(String complaintId) throws Exception;
	public int registerComplaint(Complaint complaint) throws Exception;
	public int addAddress(Address address) throws Exception;

}
