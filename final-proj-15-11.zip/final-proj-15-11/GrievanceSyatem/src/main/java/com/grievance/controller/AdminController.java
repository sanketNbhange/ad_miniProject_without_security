package com.grievance.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grievance.dto.DepartmentHeadDto;
import com.grievance.model.Department;
import com.grievance.model.User;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;

public class AdminController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	DepartmentI deptService=new DepartmentService();
	AdminI adminService=new AdminService();
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getPathInfo();
		if(path.equals("/addemployee")) {			
			try {
				
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String password = request.getParameter("password");
				String mobileNumber = request.getParameter("mobileNo");
				String role=request.getParameter("role");
				adminService.registerEmployee(name, email, password, mobileNumber, role);
				response.sendRedirect("/GrievanceSyatem/index.jsp");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(path.equals("/adddept")) {			
			try {
				List<User> list=new ArrayList<User>();
				list=adminService.getAllFreeDeptHead();
				request.setAttribute("allEmployees", list);
				String deptName=request.getParameter("deptname");
				String username=request.getParameter("username");
				request.getRequestDispatcher("/admin/add-dept1.jsp").forward(request, response);
				adminService.registerDepartment(deptName, username);
				response.sendRedirect("/GrievanceSyatem/index.jsp");							
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if(path.equals("/managedept")) {			
			try {
					System.out.println("hello");
				List<Department> departments=adminService.getAllDepartment();
				List<DepartmentHeadDto> departmentInfo=adminService.getAllDepartmentInfo();
				request.setAttribute("departmentInfo",departmentInfo);
				request.setAttribute("allDepartment",departments );
				request.getRequestDispatcher("/admin/manage-dept.jsp").forward(request, response);							
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/deletedept")) {			
			try {
				adminService.deleteDepartment(request.getParameter("deptid"));
				List<Department> departments=adminService.getAllDepartment();
				request.setAttribute("allDepartment",departments );
				response.sendRedirect("/GrievanceSyatem/AdminController/managedept");				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/editdept")) {			
			try {
				String deptId = request.getParameter("deptid");
				Department department=adminService.getDepartmentById(deptId);
				request.setAttribute("department", department);
				List<User> list=new ArrayList<User>();
				list=adminService.getAllFreeDeptHead();
				request.setAttribute("allEmployees", list);
				request.getRequestDispatcher("/admin/update-dept.jsp").forward(request, response);						
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if(path.equals("/updatedept")) {			
			try {
				String deptName = request.getParameter("deptname");
				String userName = request.getParameter("username");
				String deptId=request.getParameter("deptid");
				adminService.updateDepartment(deptName, userName, deptId);
				response.sendRedirect("/GrievanceSyatem/AdminController/managedept");

			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
