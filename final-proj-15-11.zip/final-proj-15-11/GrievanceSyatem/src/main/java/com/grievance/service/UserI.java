package com.grievance.service;

import com.grievance.model.User;

public interface UserI {

	public static  String  getUserId () { 
		System.out.println("userI");
		return "U"+Math.round(Math.random() * 9999);
		}
	
	public User login(String email, String password) throws Exception;
}
