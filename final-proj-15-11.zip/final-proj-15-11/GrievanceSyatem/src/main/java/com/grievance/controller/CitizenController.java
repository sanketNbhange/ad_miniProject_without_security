package com.grievance.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.grievance.model.Complaint;
import com.grievance.model.Department;
import com.grievance.service.AdminI;
import com.grievance.service.AdminService;
import com.grievance.service.CitizenService;
import com.grievance.service.DepartmentI;
import com.grievance.service.DepartmentService;

import java.io.InputStream;
import java.util.List;

import javax.servlet.http.Part;

@MultipartConfig( fileSizeThreshold = 1024*1024,maxFileSize = 1024*1024*5, maxRequestSize = 1024*1024*5*5)   // upload file's size up to 16MB
public class CitizenController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	CitizenService citizenService = new CitizenService();
	AdminI adminService=new AdminService();
	DepartmentI deptService = new DepartmentService();   

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {	
		String path = request.getPathInfo();
		if (path.equals("/adduser")) {
			try {
				String name = request.getParameter("name");
				String email = request.getParameter("email");
				String password = request.getParameter("password");
				String mobileNumber = request.getParameter("mobileNo");
				String houseNo = request.getParameter("houseNo");
				String landMark = request.getParameter("landmark");
				String pincode = request.getParameter("pincode");
				citizenService.registerCitizen(name, email, password, mobileNumber, houseNo, landMark, pincode);
				System.out.println("before");
				response.sendRedirect("/GrievanceSyatem/index.jsp");
				System.out.println("after");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (path.equals("/addComplaint")) {
			Part filePart = request.getPart("screenshot");
			InputStream inputStream = filePart.getInputStream();
			byte[] doc = new byte[inputStream.available()];
			String complaintMsg = request.getParameter("complaintmsg");
			getServletContext().getRequestDispatcher("/Message.jsp").forward(request, response);
			try {
				citizenService.addComplaint(complaintMsg, doc, request.getParameter("deptId"));
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else if(path.equals("/registerComplaint")) {			
			try {
				List<Department> listDept = adminService.getALLDepartment();
				request.setAttribute("department",listDept );
				getServletContext().getRequestDispatcher("/citizen/register-complaint.jsp").forward(request, response);

			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		else if(path.equals("/listComplaint")) {
			try {
				List<Complaint> complaints = citizenService.getAllCitizenComplaints("U107");
				request.setAttribute("complaints",complaints);
				request.getRequestDispatcher("/citizen/view-complaints.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
		else if(path.equals("/editcomplaint")) {
			try {
				String complaintId=request.getParameter("complaintid");
				request.setAttribute("complaintid",complaintId);
				request.getRequestDispatcher("/citizen/update-complaint.jsp").forward(request, response);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		else if(path.equals("/updateremark")) {
			try {
				String complaintId=request.getParameter("complaintid");
				String message = request.getParameter("message");
				citizenService.updateCitizenRemark(complaintId, message);
				response.sendRedirect("/GrievanceSyatem/CitizenController/listComplaint");
			} catch (Exception e) {
				e.printStackTrace();
			}					
		}		
		else if(path.equals("/sendreminder")) {
			try {
				String complaintId=request.getParameter("complaintid");
				citizenService.updateReminder(complaintId);
				response.sendRedirect("/GrievanceSyatem/CitizenController/listComplaint");
			} catch (Exception e) {
				e.printStackTrace();
			}	
		}
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("/CitizenController/*");
		doGet(request, response);
	}


}
