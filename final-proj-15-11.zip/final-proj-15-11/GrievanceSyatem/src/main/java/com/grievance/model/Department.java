package com.grievance.model;


public class Department {
	private String deptId;
	private String deptName;
	
	private String userId;
	
	
	public Department() {
		super();
		
	}

	public Department(String deptId, String deptName, String userId) {
		this.deptId = deptId;
		this.deptName = deptName;
		this.userId = userId;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptName=" + deptName + ", userId=" + userId + "]";
	}
	
	

}
