package com.grievance.model;

public enum Role {
	ADMIN,
	DEPARTMENTHEAD,
	CITIZEN

}
