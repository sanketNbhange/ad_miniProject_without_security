package com.grievance.model;
//import java.sql.Blob;
import java.time.LocalDate;
import java.util.Arrays;
//import java.util.Date;
//import javax.swing.ImageIcon;

public class Complaint {
	private String complaintId;	
	private String complaintMsg;
	private byte[] docs;
	private int updateCount;
	private LocalDate complaintDate;
	private LocalDate resolvedDate;
	private String complaintStatus;
	private String userId;
	private String deptId;
	private String addressId;
	private String userRemark;
	private String headRemark;
	private LocalDate lastupdate;

	//	public String generateComplaintId(){
	//		return "C"+ Math.round(Math.random()*99999);	
	//	}

	//Foreign Keys




	public Complaint() {
		super();
	}

	public Complaint(String complaintId, String complaintMsg, byte[] docs, int updateCount, LocalDate complaintDate,
			LocalDate resolvedDate, String complaintStatus, String userId, String deptId, String addressId,
			String userRemark, String headRemark, LocalDate lastupdate) {
		super();
		this.complaintId = complaintId;
		this.complaintMsg = complaintMsg;
		this.docs = docs;
		this.updateCount = updateCount;
		this.complaintDate = complaintDate;
		this.resolvedDate = resolvedDate;
		this.complaintStatus = complaintStatus;
		this.userId = userId;
		this.deptId = deptId;
		this.addressId = addressId;
		this.userRemark = userRemark;
		this.headRemark = headRemark;
		this.lastupdate = lastupdate;
	}

	public String getComplaintId() {
		return complaintId;
	}

	public void setComplaintId(String complaintId) {
		this.complaintId = complaintId;
	}

	public String getComplaintMsg() {
		return complaintMsg;
	}

	public void setComplaintMsg(String complaintMsg) {
		this.complaintMsg = complaintMsg;
	}

	public byte[] getDocs() {
		return docs;
	}

	public void setDocs(byte[] docs) {
		this.docs = docs;
	}

	public int getUpdateCount() {
		return updateCount;
	}

	public void setUpdateCount(int updateCount) {
		this.updateCount = updateCount;
	}

	public LocalDate getComplaintDate() {
		return complaintDate;
	}

	public void setComplaintDate(LocalDate complaintDate) {
		this.complaintDate = complaintDate;
	}

	public LocalDate getResolvedDate() {
		return resolvedDate;
	}

	public void setResolvedDate(LocalDate resolvedDate) {
		this.resolvedDate = resolvedDate;
	}

	public String getComplaintStatus() {
		return complaintStatus;
	}

	public void setComplaintStatus(String complaintStatus) {
		this.complaintStatus = complaintStatus;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getAddressId() {
		return addressId;
	}

	public void setAddressId(String addressId) {
		this.addressId = addressId;
	}

	public String getUserRemark() {
		return userRemark;
	}

	public void setUserRemark(String userRemark) {
		this.userRemark = userRemark;
	}

	public String getHeadRemark() {
		return headRemark;
	}

	public void setHeadRemark(String headRemark) {
		this.headRemark = headRemark;
	}

	public LocalDate getLastupdate() {
		return lastupdate;
	}

	public void setLastupdate(LocalDate lastupdate) {
		this.lastupdate = lastupdate;
	}

	@Override
	public String toString() {
		return "Complaint [complaintId=" + complaintId + ", complaintMsg=" + complaintMsg + ", docs="
				+ Arrays.toString(docs) + ", updateCount=" + updateCount + ", complaintDate=" + complaintDate
				+ ", resolvedDate=" + resolvedDate + ", complaintStatus=" + complaintStatus + ", userId=" + userId
				+ ", deptId=" + deptId + ", addressId=" + addressId + ", userRemark=" + userRemark + ", headRemark="
				+ headRemark + ", lastupdate=" + lastupdate + "]";
	}


}